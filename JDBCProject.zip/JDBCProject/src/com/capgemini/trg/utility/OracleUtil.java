package com.capgemini.trg.utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class OracleUtil {
	//optional for JDBC API 4.0
 static{
	 try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
	} catch (ClassNotFoundException e) {
		
		e.printStackTrace();
	}
 }
 public static Connection getConnection(){
	 Connection connection = null;
	 try{
		 connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","hr","India123");
		 return connection;
	 }catch(SQLException e){
		 e.printStackTrace();
		 
	 }
	 return null;
 }
}
