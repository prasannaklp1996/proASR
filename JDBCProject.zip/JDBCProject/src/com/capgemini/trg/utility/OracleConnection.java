  
package com.capgemini.trg.utility;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

import oracle.jdbc.pool.OracleDataSource;

public class OracleConnection {

	static{
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	public static Connection getConnection(){
		/*try{
			OracleDataSource oracleDataSource=new OracleDataSource();
			oracleDataSource.setURL("jdbc:oracle:thin:@localhost:1521:XE");
			oracleDataSource.setUser("hr");
			oracleDataSource.setPassword("India123");
			oracleDataSource.setDriverType("thin");
			oracleDataSource.setNetworkProtocol("tcp");
			return oracleDataSource.getConnection();
			
			
		}catch(SQLException e){
			e.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	
*/
		try{
		Properties properties=DatabaseProperties.loadProperties();
		System.out.println(properties.getProperty("url"));
		OracleDataSource oracleDataSource=new OracleDataSource();
		oracleDataSource.setURL(properties.getProperty("url"));
		oracleDataSource.setUser(properties.getProperty("username"));
		oracleDataSource.setPassword(properties.getProperty("password"));
		oracleDataSource.setDriverType(properties.getProperty("drivertype"));
		oracleDataSource.setNetworkProtocol(properties.getProperty("protocol"));
		return oracleDataSource.getConnection();
		
		
	}catch(SQLException e){
		e.printStackTrace();
	}catch(Exception e){
		e.printStackTrace();
	}
	return null;
	}
}
 
 

