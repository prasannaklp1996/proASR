package com.capgemini.trg.ui;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

import com.capgemini.trg.utility.OracleUtil;

public class AddEmployeeProc {

	public static void main(String[] args) {
		String sql="{call add_employee(?,?,?,?,?)}";
		try(Connection connection=OracleUtil.getConnection();
				CallableStatement callableStatement=connection.prepareCall(sql);
			){
			callableStatement.setInt(1,2);
			callableStatement.setString(2, "Rohan");
			callableStatement.setString(3, "Analyst");
			callableStatement.setDouble(4, 5000.00);
			callableStatement.setInt(5,60);
			
			boolean bool=callableStatement.execute();
			if(bool==true){
			System.out.println("Employee added");
			}else{
				System.out.println("Unable to add");
			}
		}catch(SQLException e){
			e.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}

	}

}
