package com.capgemini.trg.ui;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import com.capgemini.trg.utility.OracleUtil;

public class NewEmployee {

	public static void main(String[] args) {
		insertEmployee();
		selectEmployee();
		//deleteEmployee();
		//selectEmployee();
	}

	private static void deleteEmployee() {
		String sql="delete from emp where deptno=?";
		try(Connection connection=OracleUtil.getConnection();
				PreparedStatement preparedStatement=connection.prepareStatement(sql);
					
				){
			preparedStatement.setInt(1, 50);
			int n=preparedStatement.executeUpdate();
			if(n>0){
				System.out.println("data deleted");
			}else{
				System.out.println("not deleted");
			}
		}catch(SQLException e){
					e.printStackTrace();
					
				}catch(Exception e){
					e.printStackTrace();
				}
		
	}

	private static void insertEmployee() {
		String sql="insert into emp(empno,ename,job,hiredate,sal,comm,deptno) values(?,?,?,?,?,?,?)";
		try(Connection connection=OracleUtil.getConnection();
			PreparedStatement preparedStatement=connection.prepareStatement(sql);
				
			){
				preparedStatement.setInt(1, 1);
				preparedStatement.setString(2,"Udaya");
				preparedStatement.setString(3, "Analyst");
				String sdate="12/08/2016";
				//convert String to java.util.Date
				DateFormat dateFormat=new SimpleDateFormat("dd/MM/yyyy");
				java.util.Date udate=dateFormat.parse(sdate);
				//convert java.util.Date to java.sql.Date
				java.sql.Date hdate=new java.sql.Date(udate.getTime());
				preparedStatement.setDate(4,hdate);
				preparedStatement.setDouble(5, 17000.00);
				preparedStatement.setDouble(6, 0.01);
				preparedStatement.setInt(7, 50);
				int n=preparedStatement.executeUpdate();
				if(n>0){
				System.out.println("Data inserted");
				}else{
					System.out.println("Unable to add details...");
				}
			
		}catch(SQLException e){
			e.printStackTrace();
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public static void selectEmployee(){
	String sql = "select * from emp where deptno=?";
	try(
			Connection connection=OracleUtil.getConnection();
			PreparedStatement preparedStatement=connection.prepareStatement(sql);
			){
		//fill up placeholders
		preparedStatement.setInt(1, 50);
	
		ResultSet resultSet=preparedStatement.executeQuery();
		if(!resultSet.next()){
			System.out.println("No data found");
		}else{
		do{
			listEmployees(resultSet);
			
		}while(resultSet.next());
		}
	}catch(SQLException e){
		e.printStackTrace();
		
	}catch(Exception e){
		e.printStackTrace();
	}
	}
	private static void listEmployees(ResultSet resultSet) {
		try {
			System.out.println("Empno: "+resultSet.getInt("empno"));
			System.out.println("Empname: "+resultSet.getString("ename"));
			System.out.println("Job: "+resultSet.getString("job"));
			System.out.println("Hiredate: "+resultSet.getDate("hiredate"));
			System.out.println("Deptno: "+resultSet.getInt("deptno"));
			
			System.out.println("----------------");
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
	}
}
