
package com.capgemini.trg.ui;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;



public class EmployeeTotalPay {

	public static void main(String[] args) {
		String sql= "{? = call get_emp_pay(?)}";
		try(
				Connection connection= DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","hr","India123");
				CallableStatement callableStatement=connection.prepareCall(sql);

				){
			callableStatement.registerOutParameter(1, java.sql.Types.DOUBLE);
			callableStatement.setInt(2, 7499);
			callableStatement.execute();
			double total=callableStatement.getDouble(1);
			System.out.println("Total pay is "+total);

		}catch(SQLException e){
			e.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}
	}

} 
 

