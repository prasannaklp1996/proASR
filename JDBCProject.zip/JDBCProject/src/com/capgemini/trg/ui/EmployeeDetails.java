  
package com.capgemini.trg.ui;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

import com.capgemini.trg.utility.OracleUtil;

public class EmployeeDetails {

	public static void main(String[] args) {

		String sql="{call get_employee_details(?,?,?,?,?)}";
		try(
				Connection connection=OracleUtil.getConnection();
				CallableStatement callableStatement=connection.prepareCall(sql);

				){
			callableStatement.setInt(1, 7369);
			callableStatement.registerOutParameter(2, java.sql.Types.VARCHAR);
			callableStatement.registerOutParameter(3, java.sql.Types.VARCHAR);;
			callableStatement.registerOutParameter(4, java.sql.Types.DOUBLE);
			callableStatement.registerOutParameter(5, java.sql.Types.INTEGER);
			callableStatement.execute();
			System.out.println("Empno:"+7396);
			System.out.println("Ename:"+callableStatement.getString(2));
			System.out.println("Job:"+callableStatement.getString(3));
			System.out.println("Salary:"+callableStatement.getDouble(4));
			System.out.println("Deptno:"+callableStatement.getInt(5));

		}catch(SQLException e){
			e.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}

	}

} 
 
