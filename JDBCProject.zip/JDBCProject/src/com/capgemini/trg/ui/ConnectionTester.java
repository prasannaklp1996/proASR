package com.capgemini.trg.ui;

import java.sql.Connection;



import com.capgemini.trg.utility.OracleConnection;
import com.capgemini.trg.utility.OracleUtil;

public class ConnectionTester {

	public static void main(String[] args) {
		try{
		//Connection connection=OracleUtil.getConnection();
		Connection connection=OracleConnection.getConnection();
		if(connection==null){
			System.out.println("Unable to connect to database");
		}else{
			System.out.println("Connected to database..");
		}
		}catch(Exception e){
			e.printStackTrace();
			
		}

	}

}
