package com.capgemini.trg.ui;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.capgemini.trg.utility.OracleUtil;

public class SelectDemo {

	public static void main(String[] args) throws SQLException {
		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet=null;
		String sql="select empno,ename,job,sal,deptno from emp";
		try{
			connection=OracleUtil.getConnection();
			statement = connection.createStatement();
			resultSet = statement.executeQuery(sql);
			while(resultSet.next()){
				System.out.println("Empno: "+resultSet.getInt("empno"));
				System.out.println("Empname: "+resultSet.getString("ename"));
				System.out.println("Job: "+resultSet.getString(3));//we can also specify column index
				System.out.println("Salary: "+resultSet.getDouble("sal"));
				System.out.println("Deptno: "+resultSet.getString("deptno"));
				System.out.println("------------------------");
			}
			
		}catch(SQLException e){
			e.printStackTrace();
			
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			resultSet.close();
			statement.close();
			connection.close();
			
		}

	}

}
