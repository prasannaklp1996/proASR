package com.capgemini.trg.ui;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capgemini.trg.utility.OracleUtil;

public class SelectTester {

	public static void main(String[] args) {
		String sql = "select * from emp where deptno=? and job=?";
		try(
				Connection connection=OracleUtil.getConnection();
				PreparedStatement preparedStatement=connection.prepareStatement(sql);
				){
			//fill up placeholders
			preparedStatement.setInt(1, 20);
			preparedStatement.setString(2, "MANAGER");
			ResultSet resultSet=preparedStatement.executeQuery();
			if(!resultSet.next()){
				System.out.println("No data found");
			}else{
			do{
				listEmployees(resultSet);
				
			}while(resultSet.next());
			}
		}catch(SQLException e){
			e.printStackTrace();
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	private static void listEmployees(ResultSet resultSet) {
		try {
			System.out.println("Empno: "+resultSet.getInt("empno"));
			System.out.println("Empname: "+resultSet.getString("ename"));
			System.out.println("Job: "+resultSet.getString("job"));
			System.out.println("Hiredate: "+resultSet.getDate("hiredate"));
			System.out.println("----------------");
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
	}

}
