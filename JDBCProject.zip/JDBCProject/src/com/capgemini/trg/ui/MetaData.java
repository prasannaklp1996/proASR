package com.capgemini.trg.ui;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import com.capgemini.trg.utility.OracleConnection;

public class MetaData {

	public static void main(String[] args) {
		String sql="select * from emp";
		try(
				Connection connection=OracleConnection.getConnection();
				Statement statement = connection.createStatement();
				){
				DatabaseMetaData dbMetadata = connection.getMetaData();
				System.out.println(dbMetadata.supportsSavepoints());
				System.out.println(dbMetadata.getURL());
				System.out.println(dbMetadata.getUserName());
				//.System.out.println(dbMetadata.getTables(null, null, "TABLE", ));
				System.out.println(dbMetadata.getDriverName());
				System.out.println(dbMetadata.getDatabaseProductName());
				System.out.println(dbMetadata.getDatabaseProductVersion());
				System.out.println("---------------------------");
				ResultSet resultSet=statement.executeQuery(sql);
				ResultSetMetaData rsMetaData=resultSet.getMetaData();
				
				for(int i=1;i<=rsMetaData.getColumnCount();i++){
					System.out.println(rsMetaData.getColumnName(i)+":"+rsMetaData.getColumnTypeName(i)+"("+rsMetaData.getColumnType(i)+")");
				
				}
			
				
		}catch(SQLException e){
			e.printStackTrace();
		}	
		
	}

}
