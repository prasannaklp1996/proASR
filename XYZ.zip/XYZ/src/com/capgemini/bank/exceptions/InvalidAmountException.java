package com.capgemini.bank.exceptions;

public class InvalidAmountException extends Exception {

	public InvalidAmountException(String str)
	{
		super(str);
	}
	
}
