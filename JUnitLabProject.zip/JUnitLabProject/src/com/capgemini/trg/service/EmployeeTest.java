package com.capgemini.trg.service;

import static org.junit.Assert.assertNull;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class EmployeeTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test(expected=EmployeeException.class)
	public void testEmployeeException() {
		try {
			Employee employee=new Employee(100L,"John",2000.00,"Clerk");
			assertNull(employee);
			
		} catch (EmployeeException e) {
			
			e.printStackTrace();
		}
	}
	

}
