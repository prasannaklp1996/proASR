package com.capgemini.trg.service;

public class Person {

		private String firstName;
		private String lastName;
		String gender;
		private long  phoneNumber;
		public Person(String firstName, String lastName, String gender,
				long phoneNumber) {
			super();
			this.firstName = firstName;
			this.lastName = lastName;
			this.gender = gender;
			this.phoneNumber = phoneNumber;
		}
		public String getFirstName() {
			return firstName;
		}
		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}
		public String getLastName() {
			return lastName;
		}
		public void setLastName(String lastName) {
			this.lastName = lastName;
		}
		public String getGender() {
			return gender;
		}
		public void setGender(String gender) {
			this.gender = gender;
		}
		public long getPhoneNumber() {
			return phoneNumber;
		}
		public void setPhoneNumber(long phoneNumber) {
			this.phoneNumber = phoneNumber;
		}
		
		public void display()
		{
			System.out.println("Person Details:");
			System.out.println("_______________");
			System.out.println("First Nmae: "+getFirstName());
			System.out.println("Last Name: "+getLastName());
			System.out.println("Gender: "+getGender());
			System.out.println("phone number: "+getPhoneNumber());
		}
		
	}




