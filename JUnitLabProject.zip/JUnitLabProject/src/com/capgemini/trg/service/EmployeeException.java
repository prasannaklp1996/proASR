package com.capgemini.trg.service;

public class EmployeeException extends Exception{
	private Double salary;

	public EmployeeException() {
		super();
	}

	public EmployeeException(Double salary) {
		super();
		this.salary = salary;
	}

	public Double getSalary() {
		return salary;
	}

	public void setSalary(Double salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		
		return "Employee Salary should be greater than Rs.3000.00";
	}

	

}
