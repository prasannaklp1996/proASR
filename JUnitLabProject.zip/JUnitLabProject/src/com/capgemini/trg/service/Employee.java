package com.capgemini.trg.service;
public class Employee {
	
 private Long id;
 private String name;
 private Double salary;
 private String designation;
 private String insuranceScheme;
 public Employee() {
	super();
}
 
public Employee(Long id, String name, Double salary, String designation)throws EmployeeException {
	super();
	if(salary<3000.00){
		throw new EmployeeException(); 
	}
	this.id = id;
	this.name = name;
	
	this.salary=salary;
	this.designation = designation;
}

public Employee(Long id, String name, Double salary, String designation,
		String insuranceScheme) /*throws EmployeeException ,EmployeeInsuranceSchemeException*/{
	super();
	this.id = id;
	this.name = name;
	this.salary = salary;
	this.designation = designation;
	this.insuranceScheme = insuranceScheme;
	
}
public Long getId() {
	return id;
}
public void setId(Long id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public Double getSalary() {
	return salary;
}
public void setSalary(Double salary) {
	this.salary = salary;
}
public String getDesignation() {
	return designation;
}
public void setDesignation(String designation) {
	this.designation = designation;
}
public String getInsuranceScheme() {
	return insuranceScheme;
}
public void setInsuranceScheme(String insuranceScheme) {
	this.insuranceScheme = insuranceScheme;
}
@Override
public String toString() {
	return "Employee details.."+"\n"+ 
			"id=" + getId() +"\n"+ 
			"name=" + getName() +"\n"+
			"salary=" + getSalary()+"\n"+
			"designation=" + getDesignation() +"\n"+ 
			"insuranceScheme="+ getInsuranceScheme();
}





 
}
