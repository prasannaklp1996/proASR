package com.cg.eis.pl;

import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;
import com.cg.eis.exception.EmployeeInsuranceSchemeException;
import com.cg.eis.service.EmployeeInsuranceInterface;

public  class User {
	Employee employee;

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter employee name");
		String name=scanner.nextLine();
		System.out.println("Enter employee designation");
		String designation=scanner.nextLine();
		System.out.println("Enter the employee id");
		Long id =scanner.nextLong();

		System.out.println("Enter employee salary");
		Double salary=scanner.nextDouble();
		User user=new User();
		Employee employee1;
		try {
			employee1 = new Employee(id,name,salary,designation);
		
		String insuranceScheme=user.employeeInsuranceSchemeOffers(employee1);
		Employee employee2;
	
			employee2 = new Employee(id,name,salary,designation,insuranceScheme);
			System.out.println(employee2);
		
		
		} catch (EmployeeException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}finally{
			
		}
		

	}
	public  String employeeInsuranceSchemeOffers(Employee e) {

		if(e.getSalary()>5000 && e.getSalary()<20000 && e.getDesignation().equalsIgnoreCase("System Associate")){
			e.setInsuranceScheme("Scheme C");

		}
		else if(e.getSalary()>=20000 && e.getSalary()<40000 && e.getDesignation().equalsIgnoreCase("Programmer")){
			e.setInsuranceScheme("Scheme B");

		}
		else if(e.getSalary()>=40000 && e.getDesignation().equalsIgnoreCase("Manager")){
			e.setInsuranceScheme("Scheme A");

		}
		else if(e.getSalary()<=5000 && e.getDesignation().equalsIgnoreCase("Clerk")){
			e.setInsuranceScheme("No Scheme");

		}
		else
		{
			System.out.println("Sorry!! Your designation and corresponding salary donot have any scheme..");
		}
		return e.getInsuranceScheme();
	}



}

