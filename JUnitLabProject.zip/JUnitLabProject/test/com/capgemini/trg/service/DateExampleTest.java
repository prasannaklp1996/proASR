package com.capgemini.trg.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class DateExampleTest {
	
	
	
	

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.out.println("Initialization common for all test methods.");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("Clean up after executing all test methods..");
	}

	@Before
	public void setUp() throws Exception {
		System.out.println("This executes before each test method");
	}

	@After
	public void tearDown() throws Exception {
		System.out.println("This executes after eash test method");
	}

	@Test
	public void testGetIntDay() {
		assertEquals(20,new DateExample(20,10,2018).getIntDay());
	}

	
	@Test
	public void testGetIntMonth() {
		assertEquals(10,new DateExample(20,10,2018).getIntMonth());
	}

	
	@Test
	public void testGetIntYear() {
		assertEquals(2018,new DateExample(20,10,2018).getIntYear());
	}

	

	
}
