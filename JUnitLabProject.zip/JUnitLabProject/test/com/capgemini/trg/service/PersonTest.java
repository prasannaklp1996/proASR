package com.capgemini.trg.service;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class PersonTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.out.println("Initialization common for all test methods.");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("Clean up after executing all test methods..");
	}

	@Before
	public void setUp() throws Exception {
		System.out.println("This executes before each test method");
	}
	

	@After
	public void tearDown() throws Exception {
		System.out.println("This executes after eash test method");
	}

	@Test
	public void testGetFirstName() {
		assertEquals("Udaya",new Person("Udaya","Lakshmi","F",8897108283L).getFirstName());
	}

	@Test
	public void testGetLastName() {
		assertEquals("Lakshmi",new Person("Udaya","Lakshmi","F",8897108283L).getLastName());
	}

	@Test
	public void testGetGender() {
		assertEquals("F",new Person("Udaya","Lakshmi","F",8897108283L).getGender());
		
	}

	@Test
	public void testGetPhoneNumber() {
		assertEquals(8897108283L,new Person("Udaya","Lakshmi","F",8897108283L).getPhoneNumber());
	}

	@Test
	public void testDisplay() {
		
	}

}
