package com.capgemini.trg.service;

public class HelloWorld {
	private String message="Hello World";
	
	public String getMessage(){
		return message;
	}

}
