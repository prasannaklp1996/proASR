package com.capgemini.trg.service;

public class ArithmeticOperations {
	public boolean addition(Double num1,Double num2){
		System.out.println("Add:"+(num1+num2));
	
		return true;
	}
	public boolean subtraction(Double num1,Double num2){
	System.out.println("Sub:"+(num1-num2));
	return true;
	}
	public boolean multiplication(Double num1,Double num2){
		System.out.println("Mul"+num1*num2);
		return true;
	}
	public boolean division(Double num1,Double num2){
		if(num2==0){
			throw new ArithmeticException();
			
		}else{
		System.out.println("Div"+(num1/num2));
		return true;
		}
	
	}


}
