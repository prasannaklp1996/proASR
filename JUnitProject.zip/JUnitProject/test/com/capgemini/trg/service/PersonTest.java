 
package com.capgemini.trg.service;  


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class PersonTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.out.println("Initialization common for all test methods");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("Cleanup after executing all test methods");
	}

	@Before
	public void setUp() throws Exception {
		System.out.println("Initialization code before each test method");
	}

	@After
	public void tearDown() throws Exception {
		System.out.println("Cleanup code after each test method");
	}

	@Test(expected=IllegalArgumentException.class)
	public void testPersonException() {
		
		assertNull(new Person(null,null,8000.00));
	}

	/*@Test
	public void testPersonForNotNull() {
		//fail("Not yet implemented");
		assertNotNull("Udaya",new Person("udaya",null,8000.00));
	}
	@Test
	public void testGetFullName(){
		assertEquals("Udaya lakshmi",new Person("Udaya","lakshmi",8000.00).getFullName());
	}*/
} 
 
