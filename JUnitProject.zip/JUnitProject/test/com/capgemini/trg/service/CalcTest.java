package com.capgemini.trg.service;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class CalcTest {
	ArithmeticOperations cal=new ArithmeticOperations();

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testAddition() {
		
		boolean bool=cal.addition(10.0, 20.0);
		
		assertTrue(bool);
	}

	@Test
	public void testSubtraction() {
		boolean bool=cal.subtraction(30.0, 40.0);
		assertTrue(bool);
	}

	@Test
	public void testMultiplication() {
		boolean bool=cal.multiplication(30.0, 40.0);
		assertTrue(bool);
		//assertEquals(1200.0,cal.multiplication(30.0, 40.0),0.01);
	}

	@Test
	public void testDivision() {
		boolean bool=cal.division(30.0, 0.0);
		assertTrue(bool);
	}
	

}
