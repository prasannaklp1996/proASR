package com.capgemini.trg.service;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

public class HelloWorldTest {
	@BeforeClass
	public static void beforeUnitTest(){
		System.out.println("Initialization common for all test methods.");
	}
	@AfterClass
	public static void afterUnitTest(){
		System.out.println("Clean up after executing all test methods..");
	}
	@Before
	public void beforeTestMethod(){
		System.out.println("This executes before each test method");
	}
	@After
	public void afterTestMethod(){
		System.out.println("This executes after eash test method");
	}
	@Test
	public void testGetMessage() {
		//fail("Not yet implemented");

		assertEquals("Hello World",new HelloWorld().getMessage());
	}
	@Ignore
	public void testMethod(){
		System.out.println("Ignore this method");
	}
}
